
CREATE TABLE votes IF NOT EXISTS
(
  id text PRIMARY KEY,
  vote text NOT NULL
);
